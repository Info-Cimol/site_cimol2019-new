var base_url='http://localhost/site_cimol/site/'
	function ajaxModal(id){
	$('#modal-body').html('');
	$('#modal-edit').html('');
                    $.ajax({
                            url: base_url+"admin/noticia/buscar_noticia/"+id,
                            dataType: 'json',
                            type: "post",
                            success: function(data){
                            			$('#modal-body').append("<h3 class='titulo-modal'>"+
                            					data[0].titulo+"</h3><div class='imagens-modal' id='imagens-aqui'></div><div class='conteudo'><p>"+
                            					data[0].conteudo+
                            					"</p></div>");
                            			$.each(data,function(index, element){
                            				if(index>0){
	        					    	 		$('#imagens-aqui').append(
	        					    	 		"<img src='"+base_url+element.url_imagem+element.nome+"'>");
                            				}
        					        	 	})
                            }
                    })
            }

	function imagens_formal(){
		$('#modal-edit').html('');
		$('.modal-header').html('');
		$('.modal-header').append("<p>Adicionar Imagens</p>");
		$('#modal-edit').append("<div><form method='POST' action='"+base_url+"admin/imagem/adicionar_imagens' enctype='multipart/form-data'>"+
				"<input type='file' name='imagens[]' accept='image/*' multiple>"+
				"<br/>"+
				"<button type='submit' class='btn btn-blue'>Salvar Imagens</button>"+
				"</form></div>"
		);
	}
	
	function ver_link(id, value){
			$('#link-input-'+id).val(value);
			$('#link-'+id).css('display','block');
			$('#ver-link-'+id).text("Fechar link");
			$('#ver-link-'+id).attr("onclick","fechar_link("+id+",'"+value+"');return false;");
	}
	
	function fechar_link(id, value){
		$('#link-'+id).css('display','none');
		$('#ver-link-'+id).text("Ver link");
		$('#ver-link-'+id).attr("onclick","ver_link("+id+",'"+value+"');return false;");
	}
	
	function listar_imagens(id){
		$('#modal-body').html('');
		$.ajax({
	        url: base_url+"admin/imagem/buscar_imagens/"+id,
	        dataType: 'json',
	        type: "post",
	        success: function(data){
	        	$('#modal-edit').html('');
	        	$('#modal-edit').append(
	        			"<div id='content' class='padded'>"+
	        			"</div>");
	        			$.each(data,function(index, element){
	        	        	$('#content').append( 			
	        				"<div class='div-imagem-modal controls'>"+
	    					"<img src='"+base_url+element.url_imagem+element.nome+"'>"+
	    					"<br/>"+
	    					"<a class='btn btn-default botao-excluir' onclick='excluir_imagem_noticia("+element.id+","+id+");'><i class='icon-trash'></i> </a>"+
	    					"</div>"
	    					);
	        			})
	        			$('#content').after("<div id='form-modal-imagem'><form method='POST' action='"+base_url+"admin/imagem/adicionar_imagens/"+id+"/' enctype='multipart/form-data'>"+
    		    				"<input type='file' name='imagens[]' accept='image/*' multiple>"+
    		    				"<br/>"+
    		    				"<button type='submit' class='btn btn-blue'>Salvar Imagens</button>"+
    		    				"</form></div>"		
    	        			);
	        	}
		})
	}
	
	function excluir_imagem_noticia(imagem_id,noticia_id){
		$.ajax({
	        url: base_url+"admin/noticia/excluir_imagem_noticia/"+imagem_id+"/"+noticia_id,
	        type: "post",
	        success:function () {
	        	listar_imagens(noticia_id);
	        }
		});
	}
	
	function editar_pagina(id){
		$('#modal-body').html('');
		$.ajax({
	        url: base_url+"admin/pagina/buscar_pagina/"+id,
	        dataType: 'json',
	        type: "post",
	        success: function(data){
	        			$('#modal-edit').html('');
	        			$('#modal-edit').append("<form action='"+base_url+"admin/pagina/salvar_pagina/"+id+"' method='post'>"+
	        					"<div class='padded'>"+
			                        "<div class='control-group'>"+
			                            "<label class='control-label'>Título:</label>"+
			                            "<div class='controls'>"+
			                                "<input type='text' name='pagina[titulo]' value='"+data[0].titulo+"' required/>"+
			                            "</div>"+
			                        "</div>"+
			                        "<div class='control-group'>"+
			                            "<label class='control-label'>Conteúdo:</label>"+
			                            "<div class='controls'>"+
			                            "<div class='box closable-chat-box'>"+
			                                            "<div class='chat-message-box'>"+
			                                				"<textarea name='pagina[conteudo]' rows='5' required>"+data[0].conteudo+"</textarea>"+
			                                			"</div>"+	
			                            "</div>"+
			                            "</div>"+
			                        "</div>"+
			                        "<div class='form-actions'>"+
				                    	"<button type='submit' class='btn btn-blue'>Salvar Mudanças</button>"+
				                    "</div>"+
	        				"</form>");
	        }
		})
	}

	function editar_noticia(id){
		$('#modal-body').html('');
		$.ajax({
	        url: base_url+"admin/noticia/buscar_noticia/"+id,
	        dataType: 'json',
	        type: "post",
	        success: function(data){
	        			$('#modal-edit').html('');
	        			$('#modal-edit').append("<form action='"+base_url+"admin/noticia/editar_noticia/"+id+"' method='post'>"+
	        					"<div class='padded'>"+
			                        "<div class='control-group'>"+
			                            "<label class='control-label'>Título:</label>"+
			                            "<div class='controls'>"+
			                                "<input type='text' name='noticia[titulo]' value='"+data[0].titulo+"' required/>"+
			                            "</div>"+
			                        "</div>"+
			                        "<div class='control-group'>"+
			                            "<label class='control-label'>Conteúdo:</label>"+
			                            "<div class='controls'>"+
			                            "<div class='box closable-chat-box'>"+
			                                            "<div class='chat-message-box'>"+
			                                				"<textarea name='noticia[conteudo]' rows='5' required>"+data[0].conteudo+"</textarea>"+
			                                			"</div>"+	
			                            "</div>"+
			                            "</div>"+
			                        "</div>"+
			                        "<div class='control-group'>"+
			                            "<label class='control-label'>Resumo:</label>"+
			                            "<div class='controls'>"+
			                            	"<div class='box closable-chat-box'>"+
			                                    "<div class='chat-message-box'>"+
			                                		"<textarea name='noticia[resumo]' rows='5' required>"+data[0].resumo+"</textarea>"+
			                                	"</div>"+
			                                "</div>"+	
			                            "</div>"+
			                        "</div>"+
			                        "<div class='form-actions'>"+
				                    	"<button type='submit' class='btn btn-blue'>Salvar Mudanças</button>"+
				                    "</div>"+
	        				"</form>");
	        }
	})
}