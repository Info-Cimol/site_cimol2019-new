$('document').ready(function(){
		$("<input type='file' name='imagens[]' accept='image/*' multiple>").appendTo("#imagens");
})